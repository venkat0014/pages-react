import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useLocation, useParams } from 'react-router-dom'

function Page() {
    const [data, setdata] = useState([])
    const params=useParams()
    const value=Number(params.id)+1;
    useEffect(() => {
        getData()
    },[params.id])
    const getData=()=>{
        axios.get(`https://reqres.in/api/users?page=${params.id}`).then((res)=>{
                console.log(res.data.data);
                setdata(res.data.data)
        }).catch((error)=>{console.log(error);})
    }
    return (
        <>
        <div>
        {
            Object.keys(data).map((value,index)=>{
               return <div>
               <p>id is {data[value].id} ; email is {data[value].email} ; name is {data[value].first_name + " "+ data[value].last_name }</p>
               <img src={data[value].avatar} alt="" srcset="" />

               </div>
            })
         } 
         </div>
        <Link to={`/page/${value}`}>Next Page</Link> 
        </>
    )
}

export default Page
